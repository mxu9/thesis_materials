import json
import pandas as pd

def csv_to_sharegpt_with_synthetic_response(csv_file, json_file):
    df = pd.read_csv(csv_file)
    
    converted_data = []
    # 2. 为不同情感预定义一些回复模板
    response_templates = {
        '开心': ['听起来真不错！为你感到高兴！', '这真是个好消息，分享你的喜悦！'],
        '伤心': ['听起来你很难过，我在这里陪着你。', '这确实令人伤心，如果你愿意可以多和我聊聊。'],
        '生气': ['这确实很让人生气！冷静一下。', '遇到这种情况感到愤怒是很正常的。'],
        '惊讶': ['哇，这真是出乎意料！', '真让人吃惊！'],
        '厌恶': ['这听起来确实挺让人不舒服的。', '可以理解你为什么感到厌恶。'],
        '平静': ['嗯，我明白了。', '好的。']
    }
    
    import random
    for _, row in df.iterrows():
        text = row['text']
        label = row['label']
        
        # 3. 根据情感标签，随机选择一个回复模板
        possible_responses = response_templates.get(label, ['我理解你的感受。'])
        synthetic_response = random.choice(possible_responses)
        
        # 4. 构建单轮对话数据
        conversation = [
            {"from": "human", "value": text},
            {"from": "gpt", "value": synthetic_response}
        ]
        
        # 5. 可以将情感标签作为系统提示，指导模型回复风格
        system_prompt = f"请根据用户话语中隐含的‘{label}’情感，给出有同理心的回复。"
        
        converted_item = {
            "conversations": conversation,
            "system": system_prompt
        }
        converted_data.append(converted_item)
    
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(converted_data, f, ensure_ascii=False, indent=2)
    print(f"转换完成！数据已保存至 {json_file}。请注意，助手回复是自动生成的模板，用于演示格式。")

# 使用示例
csv_to_sharegpt_with_synthetic_response('dataset.csv', 'emotion_chat_sharegpt.json')