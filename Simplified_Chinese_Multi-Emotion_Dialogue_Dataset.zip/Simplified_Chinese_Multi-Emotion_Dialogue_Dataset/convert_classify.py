import json
import pandas as pd

def csv_to_alpaca_for_classification(csv_file, json_file):
    # 1. 读取CSV数据
    df = pd.read_csv(csv_file)
    
    converted_data = []
    
    # 2. 定义情感标签到中文描述的映射（可选，但会让指令更清晰）
    label_map = {
        '平静': '平静或中性',
        '开心': '开心',
        '伤心': '伤心',
        '生气': '生气',
        '惊讶': '惊讶',
        '厌恶': '厌恶'
    }
    
    for _, row in df.iterrows():
        text = row['text']
        label = row['label']
        
        # 3. 构建Alpaca格式数据点
        data_point = {
            "instruction": "请判断以下文本所表达的主要情感。",
            "input": text,
            "output": label_map.get(label, label), # 使用映射或原标签
            # 可以添加一个固定的“系统提示”来明确任务
            "system": "你是一个情感分析助手，请根据用户输入的文本，判断其表达的主要情感类别。"
        }
        converted_data.append(data_point)
    
    # 4. 保存为JSON文件
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(converted_data, f, ensure_ascii=False, indent=2)
    print(f"转换完成！共处理{len(converted_data)}条数据，已保存至 {json_file}")

# 使用示例
csv_to_alpaca_for_classification('dataset.csv', 'emotion_classification_alpaca.json')